
<template>
	<div>
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
  },
}
</script>
<style>


</style>